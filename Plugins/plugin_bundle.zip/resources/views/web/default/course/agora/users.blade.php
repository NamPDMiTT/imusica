@push('styles_top')

@endpush

<div class="agora-users pb-30">

    <div class="user-card d-flex align-items-center border border-gray200 p-15 mx-15 mt-25 rounded-sm">
        <div class="avatar">
            <img src="" alt="" class="img-cover rounded-circle">
        </div>
        <div class="ml-10">
            <span class="font-14 font-weight-500 d-block text-dark"></span>
            <span class="font-12 text-gray">Host</span>
        </div>
    </div>


    <div class="user-card d-flex align-items-center border border-gray200 p-15 mx-15 mt-25 rounded-sm">
        <div class="avatar">
            <img src="" alt="" class="img-cover rounded-circle">
        </div>
        <div class="ml-10">
            <span class="font-14 font-weight-500 d-block text-dark"></span>
            <span class="font-12 text-gray">Student</span>
        </div>
    </div>

</div>


@push('scripts_bottom')

@endpush
